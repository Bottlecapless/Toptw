# Readme

## 开发须知

本项目采用CLion、Cmake、C++进行代码开发。

Quick CMake tutorial

https://www.jetbrains.com/help/clion/quick-cmake-tutorial.html

## runToptw

程序主入口 `mainToptw.cpp`
```shell
cd build
cmake .. # 文件有增减时，记得重新 cmake一下
make runToptw # 编译链接
./runToptw # 运行
```