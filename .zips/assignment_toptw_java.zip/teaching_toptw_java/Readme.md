---
Heuristic for TOPTW
---

Implementation in Java

+ Open project using IntelliJ IDEA
+ Open ``Module Setting`` and set your JDK

参考文献：Youcef Amarouche, Rym Nesrine Guibadj, Elhadja Chaalal, Aziz Moukrim, Effective neighborhood search with optimal splitting and adaptive memory for the team orienteering problem with time windows, Computers & Operations Research, 2020, 123, 105039.