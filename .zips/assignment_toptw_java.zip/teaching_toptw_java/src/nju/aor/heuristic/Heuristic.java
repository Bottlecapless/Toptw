package nju.aor.heuristic;

import nju.aor.common.*;

import java.util.ArrayList;
import java.util.Collections;

public class Heuristic {
    ProblemToptw inst;
    AlgoParameter param;
    Result result;
    Operator opt;

    int maxIterations = 50000;
    int maxNonImprovingIterations = 2000;
    double Ph = 0.1; // probability
    double Pl = 0.4; // probability

    long start;

    public Heuristic(ProblemToptw inst, AlgoParameter param) {
        this.inst = inst;
        this.param = param;

        this.result = new Result(inst, param);
        this.opt = new Operator(inst,result);
        start = System.currentTimeMillis();
    }

    public void run() {
        Solution sol = new Solution(inst);
        construct(sol);
        result.setBestSol(sol);
        System.out.printf("construct >\t%f\t%.2f\t%.2f\r\n", result.obj, result.sol.distance, time());

        for (int i = 1, nonImpr = 1; i <= maxIterations && nonImpr <= maxNonImprovingIterations; i++) {
            localSearch(sol);
            if (result.obj < sol.profit) {
                result.setBestSol(sol);
                nonImpr = 0;
                System.out.printf("iteration %4d >\t%.1f\t%.2f\t%.2f\r\n", i, result.obj, result.sol.distance, time());
            } else {
                nonImpr++;
            }

            perturb(sol, nonImpr);
//            construct(sol);
        }

        System.out.println("heuristic >\t ub = " + result.obj + "\t dist = " + result.sol.distance
                + "\t time = " + time());
        result.time = time();
        result.output();
    }

    void localSearch(Solution sol) {
        double best = sol.profit;
        while (true) {
            opt.interOpt(sol);
            opt.intraOpt(sol);
            opt.improve(sol);
            if (best < sol.profit) best = sol.profit;
            else break;
        }
    }

    void construct(Solution sol) {
        for (int i = 0; i < sol.unvisited.size(); i++) {
            Integer u = sol.unvisited.get(i);
            boolean inserted = false;
            for (Route route : sol.routeList) {
                for (int j = 1; j < route.rList.size(); j++) {
                    int x = route.rList.get(j - 1);
                    int y = route.rList.get(j);

                    double ex = route.earliest.get(j - 1);
                    double ly = route.latest.get(j);

                    double eu = Math.max(ex, inst.O[x]) + inst.s[x]
                            + inst.d[x][u];
                    double ey_new = Math.max(eu, inst.O[u]) + inst.s[u]
                            + inst.d[u][y];
                    double lu = Math.min(inst.C[u], ly - inst.d[u][y]
                            - inst.s[u]);
                    double lx_new = Math.min(inst.C[x], lu - inst.d[x][u]
                            - inst.s[x]);

                    if (ex < lx_new + AlgoParameter.tolerance && eu < lu + AlgoParameter.tolerance
                            && ey_new < ly + AlgoParameter.tolerance) {
                        route.add(j, u);
                        inserted = true;
                        break;
                    }
                }

                if (inserted) {
                    sol.unvisited.remove(i);
                    i--;
                    break;
                }
            }
        }
        sol.updateProfit();
    }

    void perturb(Solution sol, int no_impr) {
        // sort unrouted customer
        ArrayList<Integer> u = new ArrayList<>(inst.profitDescending);
        u.retainAll(sol.unvisited);
        sol.unvisited = u;

        Collections.shuffle(sol.routeList, AlgoParameter.random);
        double p_aver = sol.getAvgProfit();
        for (Route route : sol.routeList) {
            for (int i = 1; i < route.rList.size() - 1; i++) {
                int c = route.rList.get(i);
                double p = AlgoParameter.random.nextDouble();
                if (inst.p[c] >= p_aver && p < Ph) {
                    Integer cust = route.rList.remove(i);
                    sol.unvisited.add(cust);
                    i--;
                } else if (inst.p[c] < p_aver && p < Pl) {
                    Integer cust = route.rList.remove(i);
                    sol.unvisited.add(cust);
                    i--;
                }
            }
        }
        for (Route route : sol.routeList)
            route.update(route.rList);
        sol.updateProfit();
    }

    double time() {
        return 0.001 * (System.currentTimeMillis() - start);
    }

    boolean timeout() {
        return System.currentTimeMillis() - start > 1000L * param.timeLimit;
    }
}
