package nju.aor.heuristic;

import nju.aor.common.*;

import java.util.ArrayList;

public class Operator {
    ProblemToptw inst;
    Result result;

    public Operator(ProblemToptw inst, Result result) {
        this.inst = inst;
        this.result = result;
    }

    public void improve(Solution A) {
        relocate_0(A);
        exchange_0(A);
        A.updateProfit();
    }

    public void intraOpt(Solution A) {
        relocate_1(A);
        exchange_1(A);
        A.updateProfit();
    }

    public void interOpt(Solution A) {
        exchange_2(A);
        twoOptStar(A);
        relocate_2(A);
        A.updateProfit();
    }

    /**************************************************************************************
     * Relocate Operator
     **************************************************************************************/
    public boolean relocate_0(Solution A) {
        boolean improved = false;
        for (int i = 0; i < A.routeList.size(); i++) {
            Route route = A.routeList.get(i);
            for (int j = 0; j < route.rList.size() - 1; j++) {
                int x = route.rList.get(j);
                int y = route.rList.get(j + 1);
                double ex = route.earliest.get(j);
                double ly = route.latest.get(j + 1);
                for (int k = 0; k < A.unvisited.size(); k++) {
                    int u = A.unvisited.get(k);
                    if (ex > inst.C[u] + AlgoParameter.tolerance
                            || ly + AlgoParameter.tolerance < inst.O[u]) continue;

                    double eu = Math.max(ex, inst.O[x]) + inst.s[x]
                            + inst.d[x][u];
                    double ey_new = Math.max(eu, inst.O[u]) + inst.s[u]
                            + inst.d[u][y];
                    double lu = Math.min(inst.C[u], ly - inst.d[u][y]
                            - inst.s[u]);
                    double lx_new = Math.min(inst.C[x], lu - inst.d[x][u]
                            - inst.s[x]);

                    if (ex < lx_new + AlgoParameter.tolerance && eu < lu + AlgoParameter.tolerance
                            && ey_new < ly + AlgoParameter.tolerance) {
                        improved = true;
                        A.unvisited.remove(k);
                        if (route.add(j + 1, (u)) == false) {
                            System.out.println("relocate_0 failed!");
                        }
                        j--;
                        break;
                    }
                }
            }
        }
        return improved;
    }

    public void relocate_1(Solution A) {
        // todo: implement relocation within a route
    }

    public void relocate_2(Solution A) {
        // System.out.println("relocate_2");
        long start = System.currentTimeMillis();
        for (int i1 = 0; i1 < A.routeList.size(); i1++) {
            Route a = A.routeList.get(i1);
            for (int i2 = i1 + 1; i2 < A.routeList.size(); i2++) {
                Route b = A.routeList.get(i2);
                for (int pos = 0; pos < a.rList.size() - 1; pos++) {
                    int x1 = a.rList.get(pos);
                    int x2 = a.rList.get(pos + 1);
                    double ex1 = a.earliest.get(pos);
                    double lx2 = a.latest.get(pos + 1);
                    for (int j = 1; j < b.rList.size() - 1; j++) {
                        Integer u = b.rList.get(j);
                        if (ex1 > inst.C[u] || lx2 < inst.O[u]) continue;
                        double eu = Math.max(ex1, inst.O[x1]) + inst.s[x1]
                                + inst.d[x1][u];
                        double ex2_new = Math.max(eu, inst.O[u]) + inst.s[u]
                                + inst.d[u][x2];
                        double lu = Math.min(inst.C[u], lx2 - inst.d[u][x2]
                                - inst.s[u]);
                        double lx1_new = Math.min(inst.C[x1], lu
                                - inst.d[x1][u] - inst.s[x1]);
                        if (ex1 <= lx1_new && eu <= lu && ex2_new <= lx2) {
                            b.remove(j);
                            a.add(pos + 1, u);
                            x2 = a.rList.get(pos + 1);
                            lx2 = a.latest.get(pos + 1);
                            j--;
                        }
                    }
                }
            }
        }
        result.time_relocate_2 += 0.001 * (System.currentTimeMillis() - start);
    }

    /*************************************************************************************
     * Out Exchange Operator
     *************************************************************************************/
    public boolean exchange_0(Solution A) {
        // System.out.println("exchange_0");
        boolean improved = false;

        // todo: implement exchange with an univisted customer

        return improved;
    }

    public void exchange_1(Solution A) {
        // todo: implement exchange within a route
    }

    public void exchange_2(Solution A) {
        // todo: implement exchange between two routes
    }

    public void twoOptStar(Solution A) {
        // System.out.println("2-opt");
        long start = System.currentTimeMillis();
        for (int i = 0; i < A.routeList.size() - 1; i++) {
            Route a = A.routeList.get(i);
            for (int j = i + 1; j < A.routeList.size(); j++) {
                Route b = A.routeList.get(j);
                double pat = a.profit;
                for (int m = 0; m < a.rList.size() - 1; m++) {
                    int p = a.rList.get(m);
                    int q = a.rList.get(m + 1);
                    double ep = a.earliest.get(m);
                    double lq = a.latest.get(m + 1);
                    pat -= inst.p[p];

                    double pbt = b.profit;
                    for (int n = 0; n < b.rList.size() - 1; n++) {
                        int x = b.rList.get(n);
                        int y = b.rList.get(n + 1);
                        double ex = b.earliest.get(n);
                        double ly = b.latest.get(n + 1);
                        pbt -= inst.p[x];

                        double ey_new = Math.max(ep, inst.O[p]) + inst.s[p]
                                + inst.d[p][y];
                        double eq_new = Math.max(ex, inst.O[x]) + inst.s[x]
                                + inst.d[x][q];
                        double lp_new = Math.min(inst.C[p], ly - inst.d[p][y]
                                - inst.s[p]);
                        double lx_new = Math.min(inst.C[x], lq - inst.d[x][q]
                                - inst.s[x]);

                        if (ex <= lx_new && ep <= lp_new && eq_new <= lq
                                && ey_new <= ly && pat < pbt) {
                            ArrayList<Integer> w = new ArrayList<Integer>();
                            ArrayList<Integer> v = new ArrayList<Integer>();
                            w.addAll(b.rList.subList(n + 1, b.rList.size()));
                            v.addAll(a.rList.subList(m + 1, a.rList.size()));
                            a.setTail(m + 1, w);
                            b.setTail(n + 1, v);
                            // w.addAll(a.rList.subList(0, m + 1));
                            // v.addAll(b.rList.subList(0, n + 1));
                            // w.addAll(b.rList.subList(n + 1, b.rList.size()));
                            // v.addAll(a.rList.subList(m + 1, a.rList.size()));
                            // a.update(w);
                            // b.update(v);

                            q = a.rList.get(m + 1);
                            lq = a.latest.get(m + 1);
                            double tmp = pbt;
                            pat = pbt;
                            pbt = tmp;
                        }
                    }
                }
            }
        }
        result.time_two_opt_star += 0.001 * (System.currentTimeMillis() - start);
    }

    public void twoOpt(Solution sol) {
        // todo: implement 2-opt within one route
    }
}
