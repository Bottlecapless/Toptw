package nju.aor.common;

import com.google.gson.Gson;
import com.google.gson.GsonBuilder;

import java.io.File;

public class Result {
    String instname;
    int N;
    int m; // number of vehicles
    AlgoParameter param;

    public double time;
    public double obj; // best objective value
    public Solution sol;

    // your performance metrics
    public double time_relocate_0;
    public double time_relocate_1;
    public double time_relocate_2;
    public double time_exchange_0;
    public double time_exchange_1;
    public double time_exchange_2;
    public double time_two_opt;
    public double time_two_opt_star;

    public Result(ProblemToptw inst, AlgoParameter param) {
        this.instname = inst.instname;
        this.N = inst.N;
        this.m = inst.m;
        this.param = param;
    }

    public void setBestSol(Solution sol) {
        this.sol = new Solution(sol);
        this.obj = sol.profit;
    }

    public Solution sol() {
        return sol;
    }

    public String toCsvString() {
        return param.authorId + "," + param.authorName + "," + param.problemName + "," + instname + "," + N + "," + m + "," + param.algoName + ", " + sol.profit + ", " + time;
    }

    public String toJSonString() {
        Gson gson = new GsonBuilder().setPrettyPrinting().create();
        return gson.toJson(this);
    }

    public void output() {
        Log.start(new File(param.pathResultCsv), true);
        Log.writeln(toCsvString());
        Log.end();
        Log.start(new File(param.pathResultSol + "/sol_" + instname + "_" + m + ".json"), false);
        Log.writeln(toJSonString());
        Log.end();
    }
}
