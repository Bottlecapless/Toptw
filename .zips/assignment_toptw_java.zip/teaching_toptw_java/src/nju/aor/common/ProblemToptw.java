package nju.aor.common;

import java.util.ArrayList;
import java.util.TreeSet;

public class ProblemToptw {
    public String instname;
    public int V; // V number of vehicles that can serve all customers
    public int N; // number of vertices in graph
    public int m; // number of vehicles provided

    public double[] x; // x coordinate of a location
    public double[] y; // y coordinate of a location
    public double[] s; // service times
    public double[] p; // profit vector
    public int[] O; // time windows: open time
    public int[] C; // time windows: close time

    public double[][] d; // distance matrix
    public ArrayList<Integer> profitDescending; // customer list with profit
    // descending

    public ProblemToptw(String id, int V, int N, double[] x, double[] y,
                        double[] s, double[] p, int[] O, int[] C) {
        this.instname = id;
        this.V = V;
        this.N = N;
        this.x = x;
        this.y = y;
        this.s = s;
        this.p = p;
        this.O = O;
        this.C = C;
        this.sort();

        d = new double[N][N];
        for (int i = 0; i < N; i++) {
            d[i][i] = 0;
            for (int j = i + 1; j < N; j++) {
                double a = x[j] - x[i];
                double b = y[j] - y[i];
                d[i][j] = d[j][i] = Math.sqrt(a * a + b * b);
            }
        }
    }

    public void prepare() {
        // todo: preprocessing
        // e.g.: infeasible[i][j] = 1 if arc (i,j) never used, i.e. time window violation
    }

    void sort() {
        TreeSet<Customer> set = new TreeSet<>();
        for (int i = 1; i < N; i++) {
            set.add(new Customer(i, x[i], y[i], s[i], p[i], O[i], C[i]));
        }
        this.profitDescending = new ArrayList<>();
        for (Customer i : set)
            profitDescending.add(0, i.no);
    }

    class Customer implements Comparable<Customer> {
        int no; // id of customer
        double x; // x coordinate
        double y; // y coordinate
        double s; // service time
        double p; // profit
        int o; // time window: open time
        int c; // time window: close time

        public Customer(int no, double x, double y, double s, double p, int o,
                        int c) {
            // TODO Auto-generated constructor stub
            this.no = no;
            this.x = x;
            this.y = y;
            this.p = p;
            this.s = s;
            this.o = o;
            this.c = c;
        }

        @Override
        public int compareTo(Customer o) {
            // TODO Auto-generated method stub
            // return this.c - o.c > 0 ? 1 : -1;
            return this.p - o.p > 0 ? 1 : -1;
        }

        public String toString() {
            return no + "  " + p;
        }
    }

    public void setNumOfVehicles(int m) {
        this.m = m;
    }

    public String toString() {
        String s = "id: " + instname + " \t";
        s += "N: " + N + " \t";
        s += "V: " + V + " \t";
        s += "m: " + m;
        return s;
    }

}
