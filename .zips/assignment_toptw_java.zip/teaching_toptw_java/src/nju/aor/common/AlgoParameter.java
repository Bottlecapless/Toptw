package nju.aor.common;

import java.io.File;
import java.util.Random;

public class AlgoParameter {
    public static double tolerance = 1.0e-7;

    public String problemName;
    public String authorId;
    public String authorName;
    public String algoName;
    public int randomSeed;
    public int timeLimit;
    public String testSetPrefix;
    public String testSetExtension;
    public String pathData;

    public String pathResultSol;
    public String pathResultCsv;

    public static boolean debug;
    public static Random random;

    public AlgoParameter(String problemName, String authorId, String authorName, String algoName, int randomSeed,
                         int timeLimit, String testSetPrefix, String testSetExtension, String pathData, boolean debug) {
        this.problemName = problemName;
        this.authorId = authorId;
        this.authorName = authorName;
        this.algoName = algoName;
        this.randomSeed = randomSeed;
        this.timeLimit = timeLimit;
        this.testSetPrefix = testSetPrefix;
        this.testSetExtension = testSetExtension;
        this.pathData = pathData;
        this.debug = debug;

        this.random = new Random(randomSeed);
    }

    public String getCsvName() {
        if (testSetPrefix.isEmpty()) {
            return "result_" + algoName + ".csv";
        } else {
            return "result_" + algoName + "_" + testSetPrefix + ".csv";
        }
    }

    public void outputCsvTableTitle() {
        try {
            File csv = new File(pathResultCsv);
            Log.start(csv, false);
            Log.writeln("authorId,authorName,problemName,instance,N,m,algoName,solution,time");
            Log.end();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }

    @Override
    public String toString() {
        return "AlgoParameter{" +
                "problemName='" + problemName + '\'' +
                ", authorId='" + authorId + '\'' +
                ", authorName='" + authorName + '\'' +
                ", algoName='" + algoName + '\'' +
                ", timeLimit=" + timeLimit +
                ", testSetPrefix='" + testSetPrefix + '\'' +
                ", testSetExtension='" + testSetExtension + '\'' +
                ", pathData='" + pathData + '\'' +
                ", pathResultSol='" + pathResultSol + '\'' +
                ", pathResultCsv='" + pathResultCsv + '\'' +
                '}';
    }
}
