package nju.aor.common;

import java.util.ArrayList;
import java.util.Collections;

public class Solution implements Comparable<Solution> {
    transient ProblemToptw inst;
    public ArrayList<Route> routeList;
    public ArrayList<Integer> unvisited;
    public double profit;
    public double distance;

    public Solution(ProblemToptw inst) {
        // TODO Auto-generated constructor stub
        this.inst = inst;
        this.routeList = new ArrayList<>();
        this.unvisited = new ArrayList<>();
        this.profit = 0.0;
        this.distance = 0.0;
        // initialize empty routes
        for (int i = 0; i < inst.m; i++) {
            Route route = new Route(inst);
            this.routeList.add(route);
        }
        // random shuffle customers in the unvisited list
        for (int i = 1; i < inst.N; i++)
            unvisited.add(i);
        Collections.shuffle(unvisited, AlgoParameter.random);
    }

    public Solution(Solution sol) {
        this.inst = sol.inst;
        this.profit = sol.profit;
        this.distance = sol.distance;
        this.routeList = new ArrayList<>();
        for (Route route : sol.routeList) {
            this.routeList.add(route.clone());
        }
        this.unvisited = new ArrayList<>(sol.unvisited);
    }

    public void updateProfit() {
        profit = 0.0;
        distance = 0.0;
        for (Route route : routeList) {
            profit += route.profit;
            distance += route.earliest.get(route.earliest.size() - 1);
        }

        if (AlgoParameter.debug) check();
    }

    public boolean check() {
        boolean feasible = true;
        int cnt = unvisited.size();
        for (Route route : routeList) {
            cnt += route.rList.size() - 2;
        }
        if (cnt != inst.N - 1) {
            System.out.println("Solution.check(): Invalid solution!");
            feasible = false;
        }

        int[] appearance = new int[inst.N];
        for (Route route : routeList) {
            for (int e : route.rList) {
                appearance[e]++;
            }
        }
        for (int i = 1; i < inst.N; ++i) {
            if (appearance[i] > 1) {
                System.err.println("Solution.check() > customer " + i + " appeared " + appearance[i] + "times");
                feasible = false;
            }
        }
        if (!feasible) System.exit(-1);

        return feasible;
    }

    public void sortRoutes() {
        Collections.sort(routeList);
        Collections.reverse(routeList);
    }

    public double getAvgProfit() { // calculate average profit
        int nCustomers = 0;
        for (Route route : routeList) {
            nCustomers += route.rList.size() - 2;
        }
        return profit / nCustomers;
    }

    public int compareTo(Solution other) {
        // TODO Auto-generated method stub
        if (this.profit != other.profit) {
            return this.profit - other.profit > 0 ? -1 : 1;
        }
        return this.distance - other.distance < 0 ? -1 : 1;

    }
}
