package nju.aor.common;

import java.util.ArrayList;

public class Route implements Comparable<Route> {
    transient ProblemToptw inst;
    public ArrayList<Integer> rList; // a route starting and ending at 0, visiting a sequence of customers
    public ArrayList<Double> earliest; // earliest arrival time
    public ArrayList<Double> latest; // latest arrival time

    public double profit; // total profit of visiting all customers in the route
    public Integer hashcode;

    public Route(ProblemToptw inst) {
        this.inst = inst;
        this.profit = 0.0;
        this.rList = new ArrayList<>();
        this.earliest = new ArrayList<>();
        this.latest = new ArrayList<>();
        this.rList.add(0);
        this.rList.add(0);
        this.getArrivals();
    }

    public Route(Route route) {
        this.inst = route.inst;
        this.profit = route.profit;
        this.rList = new ArrayList<>(route.rList);
        this.earliest = new ArrayList<>(route.earliest);
        this.latest = new ArrayList<>(route.latest);
    }

    public void update(ArrayList<Integer> route) {
        this.rList = route;
        this.profit = 0.0;
        for (int i = 1; i < rList.size(); i++) {
            Integer e = rList.get(i);
            profit += inst.p[e];
        }
        this.getArrivals();
        if (AlgoParameter.debug) this.checker();
    }

    public boolean setTail(int pos, ArrayList<Integer> tail) {
        while (rList.size() > pos) {
            Integer e = rList.remove(pos);
            profit -= inst.p[e];
            earliest.remove(pos);
        }
        int p = pos;
        double eTime = earliest.get(p - 1);
        for (Integer e : tail) {
            rList.add(e);
            profit += inst.p[e];
            int x = rList.get(p - 1);
            int y = rList.get(p);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            earliest.add((eTime));
            p++;
        }

        latest.clear();
        double lTime = inst.C[0];
        latest.add(0, (lTime));
        for (int i = rList.size() - 2; i >= 0; i--) {
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            latest.add(0, (lTime));
        }

        return checker();
    }

    public boolean set(int pos, Integer cust) {
        int last = rList.get(pos);
        profit = profit - inst.p[last] + inst.p[cust];
        rList.set(pos, cust);

        // update earliest arrival time
        double eTime = earliest.get(pos - 1);
        for (int i = pos; i < rList.size(); i++) {
            double org_etime = earliest.get(i);
            int x = rList.get(i - 1);
            int y = rList.get(i);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            if (i > pos && Math.abs(org_etime - eTime) < AlgoParameter.tolerance) break;
            else earliest.set(i, (eTime));
        }

        // update latest arrivals time
        double lTime = latest.get(pos + 1);
        for (int i = pos; i >= 0; i--) {
            double org_ltime = latest.get(i);
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            if (i < pos && Math.abs(org_ltime - lTime) < AlgoParameter.tolerance) break;
            else latest.set(i, (lTime));
        }

        return checker();
    }

    public boolean add(int pos, Integer u) {
        profit = profit + inst.p[u];
        rList.add(pos, u);

        // update earliest arrival time
        earliest.add(pos, (0.0));
        double eTime = earliest.get(pos - 1);
        for (int i = pos; i < rList.size(); i++) {
            double org_etime = earliest.get(i);
            int x = rList.get(i - 1);
            int y = rList.get(i);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            if (i > pos && Math.abs(org_etime - eTime) < AlgoParameter.tolerance) break;
            else earliest.set(i, (eTime));
        }

        // update latest arrivals time
        latest.add(pos, 0.0);
        double lTime = latest.get(pos + 1);
        for (int i = pos; i >= 0; i--) {
            double org_ltime = latest.get(i);
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            if (i < pos && Math.abs(org_ltime - lTime) < AlgoParameter.tolerance) break;
            else latest.set(i, (lTime));
        }

        return checker();
    }

    public boolean remove(int pos) {
        Integer u = rList.remove(pos);
        profit -= inst.p[u];

        // update earliest arrival time
        earliest.remove(pos);
        double eTime = earliest.get(pos - 1);
        for (int i = pos; i < rList.size(); i++) {
            double org_etime = earliest.get(i);
            int x = rList.get(i - 1);
            int y = rList.get(i);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            if (Math.abs(org_etime - eTime) < AlgoParameter.tolerance) break;
            else earliest.set(i, (eTime));
        }

        // update latest arrivals time
        latest.remove(pos);
        double lTime = latest.get(pos);
        for (int i = pos - 1; i >= 0; i--) {
            double org_ltime = latest.get(i);
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            if (Math.abs(org_ltime - lTime) < AlgoParameter.tolerance) break;
            else latest.set(i, (lTime));
        }

        return checker();
    }

    public boolean exchange(int pos1, int pos2) {
        Integer x1 = rList.get(pos1);
        Integer x2 = rList.get(pos2);
        rList.set(pos1, x2);
        rList.set(pos2, x1);
        // getArrivals();

        int a = Math.min(pos1, pos2);
        int b = Math.max(pos1, pos2);
        // update earliest arrival time
        double eTime = earliest.get(a - 1);
        for (int i = a; i < rList.size(); i++) {
            double org_etime = earliest.get(i);
            int x = rList.get(i - 1);
            int y = rList.get(i);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            if (i > b && Math.abs(org_etime - eTime) < AlgoParameter.tolerance) break;
            else earliest.set(i, (eTime));
        }

        // update latest arrivals time
        double lTime = latest.get(b + 1);
        for (int i = b; i >= 0; i--) {
            double org_ltime = latest.get(i);
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            if (i < a && Math.abs(org_ltime - lTime) < AlgoParameter.tolerance) break;
            else latest.set(i, (lTime));
        }

        return checker();
    }

    public boolean checker() {
        /**
         * before to invoke checker(inst); make sure getArrivals() is done since
         * checker needs the latest arrival information
         */
        int size = rList.size();
        for (int i = 1; i < size; i++) {
            int cust = rList.get(i);
            double arr = earliest.get(i);
            if (arr > inst.C[cust] + AlgoParameter.tolerance) {
                System.out.println("route.cheker(): arrival time > C[" + cust + "]");
                return false;
            }
        }
        return true;
    }

    public void getArrivals() {
        earliest.clear();
        latest.clear();
        double eTime = inst.O[0];
        earliest.add((eTime));
        for (int i = 1; i < rList.size(); i++) {
            int x = rList.get(i - 1);
            int y = rList.get(i);
            eTime = Math.max(eTime, inst.O[x]) + inst.s[x] + inst.d[x][y];
            earliest.add((eTime));
        }

        double lTime = inst.C[0];
        latest.add(0, (lTime));
        for (int i = rList.size() - 2; i >= 0; i--) {
            int x = rList.get(i);
            int y = rList.get(i + 1);
            lTime = Math.min(inst.C[x], lTime - inst.d[x][y] - inst.s[x]);
            latest.add(0, (lTime));
        }
    }

    public Route clone() {
        // TODO Auto-generated method stub
        return new Route(this);
    }

    @Override
    public String toString() {
        // TODO Auto-generated method stub
        String s = profit + "\t [" + rList.get(0);
        for (int i = 1; i < rList.size(); i++) {
            s += "," + rList.get(i);
        }
        s += "]";
        return s;
    }

    @Override
    public int compareTo(Route o) {
        // TODO Auto-generated method stub
        if (Math.abs(this.profit - o.profit) > AlgoParameter.tolerance) {
            return this.profit - o.profit > 0 ? 1 : -1;
        }

        this.hashcode = this.rList.hashCode();
        o.hashcode = o.rList.hashCode();
        return this.hashcode - o.hashcode;
    }

    @Override
    public boolean equals(Object obj) {
        // TODO Auto-generated method stub
        Route o = (Route) obj;
        this.hashcode = this.rList.hashCode();
        o.hashcode = o.rList.hashCode();
        return this.hashcode == o.hashcode;
    }
}
