package nju.aor;

import nju.aor.common.AlgoParameter;
import nju.aor.common.ProblemToptw;
import nju.aor.heuristic.Heuristic;

import java.io.File;
import java.io.FileNotFoundException;
import java.util.*;

public class Main {

    public static void main(String[] args) throws FileNotFoundException {
        // write your code here
        System.out.println("hello toptw");

        AlgoParameter param = new AlgoParameter(
                "toptw",
                "654321",   // todo: your student id
                "Qian", // todo:  your name
                "ILS", // todo: your algo name
                3, // random seed
                60, // time limit
                "", ".txt",
                "data/toptw",
                true // all solution checks will be proceeded in debug mode
        );
        preparePaths(param);
        ArrayList<ProblemToptw> instances = readInstances(param);
        Collections.sort(instances, Comparator.comparing(inst -> inst.instname));
        System.out.println(instances.size() + " instances > ");

        instances.forEach(inst -> System.out.println("\t" + inst.instname));
        instances.forEach(inst -> inst.prepare());
        for (int m = 1; m <= 4; ++m) {
            for (ProblemToptw inst : instances) {
                inst.setNumOfVehicles(m);
                System.out.printf("\r\nSolving %s with m = %d > \r\n", inst.instname, m);
                Heuristic algo = new Heuristic(inst, param);
                algo.run();
            }
        }
    }

    static void preparePaths(AlgoParameter param) {
        try {
            File dirResult = new File("result");
            if (!dirResult.exists() || !dirResult.isDirectory()) {
                dirResult.mkdir();
            }
            File dirProblem = new File(dirResult, param.problemName);
            if (!dirProblem.exists() || !dirProblem.isDirectory()) {
                dirProblem.mkdir();
            }
            File dirAlgo = new File(dirProblem, param.algoName);
            if (!dirAlgo.exists() || !dirAlgo.isDirectory()) {
                dirAlgo.mkdir();
            }

            param.pathResultSol = dirAlgo.getAbsolutePath();
            param.pathResultCsv = dirProblem.getAbsolutePath() + "/" + param.getCsvName();
            param.outputCsvTableTitle();
        } catch (Exception e) {
            e.printStackTrace();
        }
    }


    static ArrayList<ProblemToptw> readInstances(AlgoParameter param) throws FileNotFoundException {
        File data = new File(param.pathData);

        Queue<File> que = new LinkedList<>();
        if (data.isDirectory()) {
            que.offer(data);
        }

        ArrayList<File> files = new ArrayList<>();
        while (!que.isEmpty()) {
            File folder = que.poll();
            File[] tmpFiles = folder.listFiles();
            for (File file : tmpFiles) {
                if (file.isDirectory()) {
                    que.offer(file);
                } else {
                    String fname = file.getName();
                    if (fname.startsWith(param.testSetPrefix) && fname.endsWith(param.testSetExtension)) {
                        files.add(file);
                    }
                }
            }
        }

//        System.out.println(files.size() + " instances > ");
//        files.forEach(file -> System.out.println("\t" + file.getName()));
        ArrayList<ProblemToptw> instances = new ArrayList<>();
        for (File file : files) {
            ProblemToptw inst = readInstance(file);
            instances.add(inst);
        }
        return instances;
    }

    public static ProblemToptw readInstance(File file) throws FileNotFoundException {
        String id = file.getName();
        Scanner cin = new Scanner(file);
        cin.next();
        int V = cin.nextInt();
        int N = cin.nextInt() + 1;
        cin.next();

        cin.next();
        cin.next();

        double[] x = new double[N];
        double[] y = new double[N];
        double[] s = new double[N];
        double[] p = new double[N];
        int[] O = new int[N];
        int[] C = new int[N];

        int i = 0;
        while (cin.hasNext()) {
            cin.next();
            x[i] = cin.nextDouble();
            y[i] = cin.nextDouble();
            s[i] = cin.nextDouble();
            p[i] = cin.nextDouble();
            cin.next();
            int a = cin.nextInt();
            while (a > 0) {
                cin.next();
                a--;
            }
            O[i] = cin.nextInt();
            C[i] = cin.nextInt();
            i++;
        }
        cin.close();
        return new ProblemToptw(id, V, N, x, y, s, p, O, C);
    }
}
